import unittest
from mhmixtools.template_sync import render_templates, list_html

class Test_list_html(unittest.TestCase):
    def test_without_parameters(self):
        print('toched')
        self.assertEqual(list_html(show=False), ['tests/template.html', 'tests/test1.html', 'tests/test2.html', 'tests/test3.html'])
    def test_hello(self):
        self.assertEqual("Hello", "Hello")

if __name__ == "__main__":
    unittest.main()